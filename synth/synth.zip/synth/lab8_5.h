/*
;************************************************************************
;  Lab: 8, Section 5
;  Name: Logan Burns
;  Class: 11303
;  PI Name: Lester Bonilla
;************************************************************************
*/


#ifndef LAB8_5_H_
#define LAB8_5_H_


void init_dac(void);
void init_dma_dac(void);
void init_dma_usart(void);
void init_usart(void);

void blockfill(uint16_t block[]);
void update_voices_from_keybuff(void);


#endif /* LAB8_5_H_ */