/*
;************************************************************************
;  Lab: 8, Section 5
;  Name: Logan Burns
;  Class: 11303
;  PI Name: Lester Bonilla
;************************************************************************
*/
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <stdint.h>
#include "timer.h"
#include "lab8_5.h"
#include "clock_test.h"

//------------------------------------local prototypes----------------------------------------
static inline void set_src_addr(uint8_t cbuff);
static int8_t ascii_to_note_id(uint8_t ch);
static inline void init_freq_lut(void);
static void init_envelopes(void);
static inline void scope_set_active_voices(void);
static inline uint16_t scope_get_sample(uint16_t sample_idx);
static void scope_update_wave(void);
static inline int32_t fmul16x16_shift10(int16_t scaled, uint16_t gain);
//------------------------------------LUTs----------------------------------------

static const int16_t sine_lut[] = {
	0, 25, 50, 75, 100, 125, 150, 174,
	199, 224, 248, 272, 297, 321, 344, 368,
	391, 414, 437, 460, 482, 504, 526, 547,
	568, 589, 609, 629, 649, 668, 687, 705,
	723, 741, 758, 775, 791, 806, 822, 836,
	851, 864, 877, 890, 902, 914, 925, 935,
	945, 954, 963, 971, 979, 986, 992, 998,
	1003, 1008, 1012, 1015, 1018, 1020, 1022, 1023,
	1023, 1023, 1022, 1020, 1018, 1015, 1012, 1008,
	1003, 998, 992, 986, 979, 971, 963, 954,
	945, 935, 925, 914, 902, 890, 877, 864,
	851, 836, 822, 806, 791, 775, 758, 741,
	723, 705, 687, 668, 649, 629, 609, 589,
	568, 547, 526, 504, 482, 460, 437, 414,
	391, 368, 344, 321, 297, 272, 248, 224,
	199, 174, 150, 125, 100, 75, 50, 25,
	0, -26, -51, -76, -101, -126, -151, -175,
	-200, -225, -249, -273, -298, -322, -345, -369,
	-392, -415, -438, -461, -483, -505, -527, -548,
	-569, -590, -610, -630, -650, -669, -688, -706,
	-724, -742, -759, -776, -792, -807, -823, -837,
	-852, -865, -878, -891, -903, -915, -926, -936,
	-946, -955, -964, -972, -980, -987, -993, -999,
	-1004, -1009, -1013, -1016, -1019, -1021, -1023, -1024,
	-1024, -1024, -1023, -1021, -1019, -1016, -1013, -1009,
	-1004, -999, -993, -987, -980, -972, -964, -955,
	-946, -936, -926, -915, -903, -891, -878, -865,
	-852, -837, -823, -807, -792, -776, -759, -742,
	-724, -706, -688, -669, -650, -630, -610, -590,
	-569, -548, -527, -505, -483, -461, -438, -415,
	-392, -369, -345, -322, -298, -273, -249, -225,
	-200, -175, -151, -126, -101, -76, -51, -26
};
static const int16_t triangle_lut[] = {
	-1024, -1008,  -992,  -976,  -960,  -944,  -928,
	-912,  -896,  -880,  -864,  -848,  -832,  -816,
	-800,  -784,  -768,  -752,  -736,  -720,  -704,
	-688,  -672,  -656,  -640,  -624,  -608,  -592,
	-576,  -560,  -544,  -528,  -512,  -496,  -480,
	-464,  -448,  -432,  -416,  -400,  -384,  -368,
	-352,  -336,  -320,  -304,  -288,  -272,  -256,
	-240,  -224,  -208,  -192,  -176,  -160,  -144,
	-128,  -112,   -96,   -80,   -64,   -48,   -32,
	-16,     0,    16,    32,    48,    64,    80,
	96,   112,   128,   144,   160,   176,   192,
	208,   224,   240,   256,   272,   288,   304,
	320,   336,   352,   368,   384,   400,   416,
	432,   448,   464,   480,   496,   512,   528,
	544,   560,   576,   592,   608,   624,   640,
	656,   672,   688,   704,   720,   736,   752,
	768,   784,   800,   816,   832,   848,   864,
	880,   896,   912,   928,   944,   960,   976,
	992,  1008,  1024,  1008,   992,   976,   960,
	944,   928,   912,   896,   880,   864,   848,
	832,   816,   800,   784,   768,   752,   736,
	720,   704,   688,   672,   656,   640,   624,
	608,   592,   576,   560,   544,   528,   512,
	496,   480,   464,   448,   432,   416,   400,
	384,   368,   352,   336,   320,   304,   288,
	272,   256,   240,   224,   208,   192,   176,
	160,   144,   128,   112,    96,    80,    64,
	48,    32,    16,     0,   -16,   -32,   -48,
	-64,   -80,   -96,  -112,  -128,  -144,  -160,
	-176,  -192,  -208,  -224,  -240,  -256,  -272,
	-288,  -304,  -320,  -336,  -352,  -368,  -384,
	-400,  -416,  -432,  -448,  -464,  -480,  -496,
	-512,  -528,  -544,  -560,  -576,  -592,  -608,
	-624,  -640,  -656,  -672,  -688,  -704,  -720,
	-736,  -752,  -768,  -784,  -800,  -816,  -832,
	-848,  -864,  -880,  -896,  -912,  -928,  -944,
	-960,  -976,  -992, -1008
};
static const uint16_t note_lut[] = {
	28, 29, 31, 33, 35, 37, 39, 41,
	44, 46, 49, 52, 55, 58, 62, 65,
	69, 73, 78, 82, 87, 92, 98, 104,
	110, 117, 123, 131, 139, 147, 156, 165,
	175, 185, 196, 208, 220, 233, 247, 262,
	277, 294, 311, 330, 349, 370, 392, 415,
	440, 466, 494, 523, 554, 587, 622, 659,
	698, 740, 784, 831, 880, 932, 988, 1047,
	1109, 1175, 1245, 1319, 1397, 1480, 1568, 1661,
	1760, 1865, 1976, 2093, 2217, 2349, 2489, 2637,
	2794, 2960, 3136, 3322, 3520, 3729, 3951, 4186
};

//------------------------------------MACROS----------------------------------------
// CLOCK
#define FCLK 32000000
#define pre 1
#define NPTS 256
#define FS 20000
#define denominator ((uint32_t)pre * (uint32_t)FS)
#define average_period (((uint32_t)FCLK + (denominator/2))/(denominator))
#define FS_REAL ((int32_t)(((uint64_t)FCLK)/((uint64_t)pre * (uint64_t)average_period)))

// DMA
#define BLOCK_SIZE NPTS // Number of samples prefilled/half the size of the DMA ping-pong buffer.
#define KEYLEN N_VOICES*3

// ADSR
#define AD_LEN NPTS/2 // length of gain[AD][], generally a few milliseconds
#define ATTACK_LEN (AD_LEN >> 2)
#define DECAY_LEN (AD_LEN - ATTACK_LEN)
#define REL_LEN	(NPTS) // length of gain[REL][], generally much longer than attack/decay

// Voices
#define N_VOICES 3 // Number of voices that will be handled
#define MAX_VOICES 3
#if N_VOICES > MAX_VOICES
#error "N_VOICES must be <= MAX_VOICES"
#endif
#define PHASE_BITS 32	// Phase accumulator width
#define LUT_BITS 8		// Number of bits in our sampled wave LUT
#define PHASE_SHIFT (PHASE_BITS - LUT_BITS) // How far we will shift the phase to the right to get the current sample
#define GAIN_FRAC 10
#define HOLD_TICKS 6 // number of blocks to hold a note for
#define NOTE_LUT_LEN (sizeof(note_lut)/sizeof(note_lut[0]))

// Mixing
#define DAC_OFFSET 2048
#define MIX_SHIFT  0
#define SUSTAIN_INIT 1500
#define ALPHA_NUM 78u
#define ALPHA_DEN 80u
#define DIV_APPROX_SHIFT 8
#define RECIP_DIV(D) ((int32_t)(((1u << DIV_APPROX_SHIFT) + (D)/2u) / (D)))
#define DIV_APPROX_INT32(x, D)((int32_t)(((int32_t)(x) * RECIP_DIV(D)) >> DIV_APPROX_SHIFT))
#define DIV_APPROX_UINT32(x, D)((uint32_t)(((uint32_t)(x) * RECIP_DIV(D)) >> DIV_APPROX_SHIFT))
#define LEVEL_INIT  ((uint32_t)SUSTAIN_INIT << 8)
#define ALPHA_MUL ((uint32_t)((ALPHA_NUM * (1u << DIV_APPROX_SHIFT) + ALPHA_DEN/2u) / ALPHA_DEN))

// Drawing
// DAC to rows
#define SCOPE_WAVE_ROWS 16
#define SCOPE_EXTRA_ROWS  2
#define SCOPE_ROWS (SCOPE_WAVE_ROWS + SCOPE_EXTRA_ROWS)
#define SCOPE_DAC_BITS 12
#define SCOPE_ROW_BITS 4
#define SCOPE_SHIFT (SCOPE_DAC_BITS - SCOPE_ROW_BITS) // how much we will shift each scope term by to fit in putty window
#define SCOPE_ROW_FROM_DAC(v) ((uint8_t)((v) >> SCOPE_SHIFT)) // shift each term to fit in the 16 rows for PuTTy
#define WAVE_ROW_FROM_DAC(v) ((uint8_t)(SCOPE_WAVE_ROWS - 1u - SCOPE_ROW_FROM_DAC(v))) // inversion of above macro for wave fill-in

// Columns
#define SCOPE_COLS 128
#define SCOPE_COLS_USED SCOPE_COLS
#define SCOPE_SAMPLES_PER_FRAME (BLOCK_SIZE * 2)
#define SCOPE_DECIMATE_FACTOR 2
#define SCOPE_VISIBLE_SAMPLES (SCOPE_COLS_USED * SCOPE_DECIMATE_FACTOR)
#if SCOPE_VISIBLE_SAMPLES > SCOPE_SAMPLES_PER_FRAME
#error "Scope: visible window exceeds available samples"
#endif

#define SCOPE_SAMPLE_INDEX_FROM_COL(col) ((uint16_t)(col) * SCOPE_DECIMATE_FACTOR)

// stepping through rows, 2 characters for EOL
#define SCOPE_STRIDE (SCOPE_COLS + 2)
#define SCOPE_ESC_LEN 3
#define SCOPE_FRAME_CHAR_BYTES (SCOPE_ROWS * SCOPE_STRIDE)
#define SCOPE_FRAME_BYTES (SCOPE_FRAME_CHAR_BYTES + SCOPE_ESC_LEN)

// general characters
#define SCOPE_CHAR_BG      ' '
#define SCOPE_CHAR_TRACE   '*'
#define SCOPE_CHAR_AXIS    '|'
#define SCOPE_CHAR_ZERO    '-'
#define SCOPE_CHAR_CORNER  '+'

// helpers
#define SCOPE_INFO_ROW (SCOPE_WAVE_ROWS + 1)
#define SCOPE_INFO_LABEL "Active Voices: "
#define SCOPE_INFO_LABEL_LEN (sizeof(SCOPE_INFO_LABEL) - 1)
#define SCOPE_INFO_VOICE_POS (SCOPE_INFO_LABEL_LEN)
#define SCOPE_FRAME_SKIP 4

//------------------------------------ENUMs----------------------------------------

// ENUMs
typedef enum {
	AD,
	SUSTAIN,
	RELEASE,
	OFF
} EnvelopeState;
enum WaveType {
	SINE,
	TRIANGLE
};

//------------------------------------Structs----------------------------------------

typedef struct {
	EnvelopeState env_state;
	uint8_t note_id;
	uint32_t phase;			// phase accumulator
	uint32_t step;			// phase increment per sample
	uint16_t env_idx;		// index into gain
	uint8_t seen_this_block;
	uint8_t hold_ticks;
}Voice;

//------------------------------------Globals----------------------------------------
// PuTTY frame buffer
static char scope_frame[SCOPE_FRAME_BYTES]; // note to self: move LUTs to progmem if memory issues arise
static uint8_t scope_prev_row[SCOPE_COLS_USED]; // each index will store the wave row corresponding to that column. will make updating the wave WAYYYYY faster :3

// current table for wave generation, call with currentwave[cwave][idx]
static const int16_t* currentwave[] = {
	sine_lut,
	triangle_lut
};

Voice voices[N_VOICES];
uint16_t pfbuff[2][BLOCK_SIZE]; // ping-pong buffer for DMA writes
uint8_t cwave = SINE; // Default wave setting, will be alternated when the corresponding key is read via USART
uint8_t cbuff = 0; // 0 or 1, selects which prefill buffer to use
uint8_t fillflag = 0; // set by DMA ISR when it is time to fill

uint8_t base = 3; // key offset, octaves, changed with zxcvbnm, (, accesses bottom 3 notes although they sound like crap)
uint8_t active_idx[N_VOICES];
uint8_t n_active = 0;
static uint32_t freq_lut[88];
static int8_t note_owner[NOTE_LUT_LEN];

// circular buffer filled by USART
uint8_t keybuff[KEYLEN]; // number of key events to buffer

static const int16_t recip_table[MAX_VOICES + 1] = {
    0,  // unused
    RECIP_DIV(1u),
    RECIP_DIV(2u),
    RECIP_DIV(3u),
    RECIP_DIV(4u),
    RECIP_DIV(5u),
    RECIP_DIV(6u),
    RECIP_DIV(7u),
    RECIP_DIV(8u),
};

// gain constants
static const uint16_t peak_gain = 2047;
static uint16_t ad_lut[AD_LEN]; // attack/decay envelope
static uint16_t rel_lut[REL_LEN]; // release array

// visualizer flags
volatile uint8_t scope_busy = 0;
volatile uint8_t scope_ready = 0;
volatile uint8_t scope_block_counter = 0;
volatile uint8_t lock_cbuff;

//------------------------------------ISRs----------------------------------------
// on transaction completion, signal main to fill other half
// swap immediately to precomputed half to avoid gaps in output
ISR(DMA_CH0_vect){
 PORTC.OUTTGL = PIN1_bm;
 cbuff ^= 1; // toggle cbuff
 DMA.INTFLAGS = DMA_CH0TRNIF_bm; // clear transfer flag
 set_src_addr(cbuff); // update source address
 DMA.CH0.CTRLA |= DMA_CH_ENABLE_bm; // Start transfer of other half
 fillflag = 1;

}

//----------------------------------DAC init--------------------------------------
void init_dac(void){
	DACA.CTRLB = DAC_CHSEL_SINGLE1_gc | DAC_CH1TRIG_bm;
	DACA.CTRLC = DAC_REFSEL_AREFB_gc;

	PORTCFG.MPCMASK = PIN2_bm | PIN3_bm;
	PORTA.PIN2CTRL = PORT_ISC_INPUT_DISABLE_gc;
	DACA.EVCTRL = DAC_EVSEL_0_gc;

	DACA.CTRLA = DAC_CH1EN_bm | DAC_CH0EN_bm | DAC_ENABLE_bm;
}

//----------------------------DMA CH0 init (DAC)--------------------------------
// CH0 always handles outputting samples to dac from filled ping-pong buffer
void init_dma_dac(void){
	// Source increments. Increment from DATAL -> DATAH.
	DMA.CH0.ADDRCTRL = DMA_CH_SRCRELOAD_BLOCK_gc | DMA_CH_SRCDIR_INC_gc | DMA_CH_DESTRELOAD_BURST_gc | DMA_CH_DESTDIR_INC_gc;

	uintptr_t dst = (uintptr_t)&DACA.CH1DATAL;
	uintptr_t src = (uintptr_t)&pfbuff[cbuff][0];

	DMA.CH0.SRCADDR0 = (uint8_t)((uint32_t)src & 0xFF);
	DMA.CH0.SRCADDR1 = (uint8_t)(((uint32_t)src >> 8) & 0xFF);
	DMA.CH0.SRCADDR2 = (uint8_t)(((uint32_t)src >> 16) & 0xFF);

	// Always send points to DAC
	DMA.CH0.DESTADDR0 = (uint8_t)((uint32_t)dst & 0xFF);
	DMA.CH0.DESTADDR1 = (uint8_t)(((uint32_t)dst >> 8) & 0xFF);
	DMA.CH0.DESTADDR2 = (uint8_t)(((uint32_t)dst >> 16) & 0xFF);

	// Initialize single shot on each TCC0 overflow
	DMA.CH0.TRIGSRC = DMA_CH_TRIGSRC_EVSYS_CH0_gc;

	DMA.CH0.REPCNT = 0;					// Unlimited Repeat
	DMA.CH0.TRFCNT = BLOCK_SIZE * 2;	// 16 bit samples, 2 bytes per DMA event

	DMA.CH0.CTRLB = DMA_CH_TRNINTLVL_MED_gc;
	PMIC.CTRL |= PMIC_MEDLVLEN_bm;

	// Burst 2 bytes per event, single-shot per trigger
	DMA.CH0.CTRLA |= DMA_CH_ENABLE_bm | DMA_CH_BURSTLEN_2BYTE_gc | DMA_CH_SINGLE_bm;
	DMA.CTRL = DMA_ENABLE_bm;
}

//----------------------------USART + DMA CH1 + CH2 init--------------------------------
void init_usart(void){

	PORTD.OUTSET = PIN3_bm;
	PORTD.DIRSET = PIN3_bm;	// TXD
	PORTD.DIRCLR = PIN2_bm;	// RXD

	// Maximize baud rate to minimize latency and allow clean output expansion
	USARTD0.BAUDCTRLA = (uint8_t)(1 & 0xFF);
	USARTD0.BAUDCTRLB = (uint8_t)(((int8_t)(0 & 0x0F) << USART_BSCALE_gp) | ((1 >> 8) & 0x0F));
	USARTD0.CTRLC = USART_CHSIZE_8BIT_gc | USART_PMODE_DISABLED_gc | USART_CMODE_ASYNCHRONOUS_gc;

	// Clear received buffer
	(void)USARTD0.DATA;
	USARTD0.STATUS = USART_TXCIF_bm;

	USARTD0.CTRLB = USART_RXEN_bm | USART_TXEN_bm |USART_CLK2X_bm;

}
void init_dma_usart(void){
	// Fixed source, increment destination within keybuff[]
	DMA.CH1.ADDRCTRL = DMA_CH_SRCRELOAD_NONE_gc | DMA_CH_SRCDIR_FIXED_gc | DMA_CH_DESTRELOAD_BLOCK_gc | DMA_CH_DESTDIR_INC_gc;

	uintptr_t src = (uintptr_t)&USARTD0.DATA;
	uintptr_t dst = (uintptr_t)&keybuff[0];

	DMA.CH1.SRCADDR0 = (uint8_t)((uint32_t)src & 0xFF);
	DMA.CH1.SRCADDR1 = (uint8_t)(((uint32_t)src >> 8) & 0xFF);
	DMA.CH1.SRCADDR2 = (uint8_t)(((uint32_t)src >> 16) & 0xFF);

	// Send points to keybuff
	DMA.CH1.DESTADDR0 = (uint8_t)((uint32_t)dst & 0xFF);
	DMA.CH1.DESTADDR1 = (uint8_t)(((uint32_t)dst >> 8) & 0xFF);
	DMA.CH1.DESTADDR2 = (uint8_t)(((uint32_t)dst >> 16) & 0xFF);

	// Trigger on each received byte
	DMA.CH1.TRIGSRC = DMA_CH_TRIGSRC_USARTD0_RXC_gc;

	DMA.CH1.REPCNT = 0;			// Unlimited Repeat
	DMA.CH1.TRFCNT = KEYLEN;	// Circular buffer size in bytes. N bytes for type, N bytes for keys

	// Burst 1 byte per character received
	DMA.CH1.CTRLA |= DMA_CH_ENABLE_bm | DMA_CH_BURSTLEN_1BYTE_gc | DMA_CH_REPEAT_bm | DMA_CH_SINGLE_bm;


	DMA.CH2.ADDRCTRL = DMA_CH_SRCRELOAD_TRANSACTION_gc | DMA_CH_SRCDIR_INC_gc | DMA_CH_DESTRELOAD_NONE_gc | DMA_CH_DESTDIR_FIXED_gc;

	src = (uintptr_t)&scope_frame[0];
	dst = (uintptr_t)&USARTD0.DATA;

	DMA.CH2.SRCADDR0 = (uint8_t)((uint32_t)src & 0xFF);
	DMA.CH2.SRCADDR1 = (uint8_t)(((uint32_t)src >> 8) & 0xFF);
	DMA.CH2.SRCADDR2 = (uint8_t)(((uint32_t)src >> 16) & 0xFF);

	// Send points to keybuff
	DMA.CH2.DESTADDR0 = (uint8_t)((uint32_t)dst & 0xFF);
	DMA.CH2.DESTADDR1 = (uint8_t)(((uint32_t)dst >> 8) & 0xFF);
	DMA.CH2.DESTADDR2 = (uint8_t)(((uint32_t)dst >> 16) & 0xFF);

	DMA.CH2.TRFCNT = SCOPE_FRAME_BYTES;	// Frame buffer size in bytes

	// Burst 1 byte per DRE
	DMA.CH2.TRIGSRC = DMA_CH_TRIGSRC_USARTD0_DRE_gc;
	DMA.CH2.CTRLA |= DMA_CH_BURSTLEN_1BYTE_gc;

	DMA.CTRL |= DMA_ENABLE_bm;
}

//------------------------------------helpers------------------------------------------
static inline void set_src_addr(uint8_t cbuff){
	// Source points from LUT
	uintptr_t src = (uintptr_t)&pfbuff[cbuff][0];

	DMA.CH0.SRCADDR0 = (uint8_t)((uint32_t)src & 0xFF);
	DMA.CH0.SRCADDR1 = (uint8_t)(((uint32_t)src >> 8) & 0xFF);
	DMA.CH0.SRCADDR2 = (uint8_t)(((uint32_t)src >> 16) & 0xFF);
}
static int8_t ascii_to_note_id(uint8_t ch){
	if (ch == 's') {
		cwave ^= 1; // toggle wave type on switch
		return -1;
	}
	 uint8_t idx;
	// interpret other characters
	switch(ch){
		case 'e': idx = base + 0; break;
		case '4': idx = base + 1; break;
		case 'r': idx = base + 2; break;
		case '5': idx = base + 3; break;
		case 't': idx = base + 4; break;
		case 'y': idx = base + 5; break;
		case '7': idx = base + 6; break;
		case 'u': idx = base + 7; break;
		case '8': idx = base + 8; break;
		case 'i': idx = base + 9; break;
		case '9': idx = base + 10; break;
		case 'o': idx = base + 11; break;
		case 'p': idx = base + 12; break;
		// Key changes (octaves)
		case ',': base = 0; return -1; // give access to lowest 3 notes
		case 'z': base = 3; return -1; // C1
		case 'x': base = 15; return -1; // C2
		case 'c': base = 27; return -1; // C3
		case 'v': base = 39; return -1; // C4
		case 'b': base = 51; return -1; // C5
		case 'n': base = 63; return -1; // C6
		case 'm': base = 75; return -1; // C7
		default: return -1;
	}
		return (int8_t)idx;
}
static void init_envelopes(void){
	const uint16_t peak = peak_gain;

	for (uint16_t i = 0; i < AD_LEN; ++i) {
		if (i < ATTACK_LEN) {
			ad_lut[i] = (uint16_t) (((uint32_t)peak * i) / (ATTACK_LEN));
		}
		else {
			uint16_t j = i - ATTACK_LEN;
			if (DECAY_LEN > 0) {
				ad_lut[i] = (uint16_t)(peak - ((uint32_t)(peak - SUSTAIN_INIT) * j)/(DECAY_LEN));
				} else {
				ad_lut[i] = SUSTAIN_INIT;
			}
		}
	}

	uint32_t level = LEVEL_INIT;
	for (uint16_t i = 0; i < REL_LEN; ++i) {
		rel_lut[i] = (uint16_t)(level >> 8);   // convert back to integer
		level = (level * ALPHA_MUL) >> DIV_APPROX_SHIFT;

	}
}
static inline void init_freq_lut(void){
	for(int i = 0; i < NOTE_LUT_LEN; i++){
		// step = (f * 2^PHASE_BITS) / Fs.
		freq_lut[i] = (uint32_t)(((uint64_t)note_lut[i] << PHASE_BITS) / FS_REAL);
	}
	return;
}
static void init_frame(void)
{
	// initialize everything to spaces + row ends

	for (uint8_t row = 0; row < SCOPE_ROWS; ++row) {
		char *line = &scope_frame[row * SCOPE_STRIDE];
		for (uint8_t col = 0; col < SCOPE_COLS_USED; ++col) {
			line[col] = SCOPE_CHAR_BG;
		}
		// Line ending
		line[SCOPE_COLS + 0] = '\r';
		line[SCOPE_COLS + 1] = '\n';
	}

	// add separator row at the end of wave rows
	if (SCOPE_WAVE_ROWS < SCOPE_ROWS) {
		for (uint8_t col = 0; col < SCOPE_COLS_USED; ++col) {
			scope_prev_row[col] = WAVE_ROW_FROM_DAC(DAC_OFFSET); // we already iterate over cols here, might as well also initialize the scope owner table
			scope_frame[SCOPE_WAVE_ROWS * SCOPE_STRIDE + col] = SCOPE_CHAR_ZERO;
		}
	}

	// add info row
	if (SCOPE_INFO_ROW < SCOPE_ROWS) {
		uint8_t pos = 0;
		const char label[] = SCOPE_INFO_LABEL;

		for (; pos < SCOPE_INFO_LABEL_LEN; ++pos) {
			scope_frame[SCOPE_INFO_ROW  * SCOPE_STRIDE + pos] = label[pos];
		}
		scope_frame[SCOPE_INFO_ROW  * SCOPE_STRIDE + pos++] = '0';
	}
	// reset cursor to home
    scope_frame[SCOPE_FRAME_CHAR_BYTES] = 0x1B;
    scope_frame[SCOPE_FRAME_CHAR_BYTES + 1] = '[';
    scope_frame[SCOPE_FRAME_CHAR_BYTES + 2] = 'H';
}
static inline void scope_set_active_voices(void)
{
	scope_frame[SCOPE_INFO_ROW * SCOPE_STRIDE + SCOPE_INFO_VOICE_POS] = (char)('0' + n_active);

}
static inline uint16_t scope_get_sample(uint16_t sample_idx){
	if (sample_idx < BLOCK_SIZE) { // current
		return pfbuff[lock_cbuff][sample_idx];
	}
	else if (sample_idx < SCOPE_SAMPLES_PER_FRAME) { // next
		return pfbuff[lock_cbuff ^ 1][sample_idx - BLOCK_SIZE];
	}
	return DAC_OFFSET;

}
static void scope_update_wave(void){
	scope_set_active_voices();

	for (uint8_t col = 0; col < SCOPE_COLS_USED; ++col) {
		uint16_t sample_idx = SCOPE_SAMPLE_INDEX_FROM_COL(col); // no need for bounds checking due to compile time checks

		uint16_t dac = scope_get_sample(sample_idx);
		uint8_t new_row = WAVE_ROW_FROM_DAC(dac); // no bound checking here either, guaranteed to be valid for DAC [0..4095] :)

		uint8_t old_row = scope_prev_row[col];
		// assumes SCOPE_WAVE_ROWS == (1 << SCOPE_ROW_BITS)
		scope_frame[old_row * SCOPE_STRIDE + col] = SCOPE_CHAR_BG;
		scope_frame[new_row * SCOPE_STRIDE + col] = SCOPE_CHAR_TRACE;
		scope_prev_row[col] = new_row;
	}
	scope_ready = 1;
}

//------------------------------------Synth Functions------------------------------------------
void update_voices_from_keybuff(void){
	// clear seen flags
	for (uint8_t v = 0; v < N_VOICES; ++v) {
		voices[v].seen_this_block = 0;
	}
	for (uint16_t i = 0; i < KEYLEN; ++i) {
		if (keybuff[i] == 0) {
        continue; // no byte received here this block
		}
		int8_t note_id = ascii_to_note_id(keybuff[i]);
		keybuff[i] = '0'; // prevent cycling the same buffered keys if the user stops holding keys

		if (note_id < 0) {
			 continue; // Skip non-notes
		}

		int8_t owner = note_owner[note_id];

		if (owner >= 0) {
			Voice *v = &voices[owner];

			if (v->env_state != OFF) {
				v->seen_this_block = 1;
				v->hold_ticks      = HOLD_TICKS;
				if (v->env_state == RELEASE) {
					v->env_state = AD;
					v->env_idx   = 0;
				}
				continue;
			}
			else {
				// stale, clear ownership
				note_owner[note_id] = -1;
			}
		}

		// Steal constants
		int8_t free_voice    = -1;
		int8_t best_release  = -1;
		int8_t chosen = -1;
		uint16_t best_rel_idx = 0;

		// not an already active note
		// Scan all voices once for stealing
		// Prefer an OFF voice
		// Otherwise, track RELEASE voice with highest env_idx
		for (uint8_t v = 0; v < N_VOICES; ++v) {
			if (voices[v].env_state == OFF) {
				free_voice = (int8_t)v;
				break;
			}
			if (voices[v].env_state == RELEASE) {
				uint16_t idx = voices[v].env_idx;
				if (idx >= best_rel_idx) {   // update idx if an older voice is present
					best_rel_idx = idx;
					best_release = (int8_t)v;
				}
			}
		}

		if (free_voice >= 0) {
			chosen = free_voice; // use free OFF voice
		}
		else if (best_release >= 0) {
			chosen = best_release; // steal oldest RELEASED voice
		}
		else {
			continue;
		}

		Voice *voice = &voices[chosen];

		if (voice->env_state != OFF) {
			uint8_t old_id = voice->note_id;
			if (note_owner[old_id] == chosen) {
				note_owner[old_id] = -1;
			}
		}

		voice->env_state = AD;
		voice->env_idx = 0;
		voice->note_id = (uint8_t)note_id;
		voice->phase = 0;
		voice->step = freq_lut[note_id];
		voice->seen_this_block = 1;
		voice->hold_ticks = HOLD_TICKS;
		note_owner[note_id] = chosen; // update note_owner table

	}

	// Transition released keys to RELEASE
	for (uint8_t v = 0; v < N_VOICES; ++v) {
		if(voices[v].env_state == OFF || voices[v].env_state == RELEASE) continue;
		if(!voices[v].seen_this_block && voices[v].hold_ticks > 0){
			voices[v].hold_ticks -= 1; // decrement hold
		}
		else if (voices[v].hold_ticks == 0)
		{
			voices[v].env_state	= RELEASE;
			voices[v].env_idx = 0;
		}
	}
}
void blockfill(uint16_t block[]){
	// list all active voices
	n_active = 0;
	for (uint8_t v = 0; v < N_VOICES; ++v) {
		if (voices[v].env_state != OFF) {
			active_idx[n_active++] = v;
		}
	}

	if (n_active == 0) {
        for (uint16_t i = 0; i < BLOCK_SIZE; ++i) {
            block[i] = DAC_OFFSET;
        }
        return;
    }

	const int16_t *wave = currentwave[cwave]; // I realized I can just precalculate these once per block rather than per sample
	int16_t recip = recip_table[n_active];

	for (uint16_t i = 0; i < BLOCK_SIZE; ++i) {
		int32_t mix = 0;
		for (uint8_t k = 0; k < n_active; ++k) {
			Voice *voice = &voices[active_idx[k]];
			uint16_t gain;

			switch (voice->env_state) {
			case SUSTAIN: gain = SUSTAIN_INIT; break;
			case RELEASE:
				gain = rel_lut[voice->env_idx];
				if (++voice->env_idx >= REL_LEN) {
					note_owner[voice->note_id] = -1;
					voice->env_state = OFF;
					}
				break;
			case AD:
				gain = ad_lut[voice->env_idx];
				if (++voice->env_idx >= AD_LEN) {
					voice->env_state = SUSTAIN;
				}
				break;
			case OFF:
			default:
				continue;
			}

			// Oscillator step
			//uint8_t index = phase_advance_and_index(&voice->phase,voice->step);
			voice->phase += voice->step;
			uint8_t index = (uint8_t)((voice->phase >> PHASE_SHIFT));
			int16_t s = wave[index];

			 int32_t scaled = fmul16x16_shift10(s,gain);
			 mix += (int32_t)scaled;
		}


        mix = (int32_t)((mix * recip) >> DIV_APPROX_SHIFT); // approximate average

		// clamp to 12-bit DAC range
		int32_t out = mix + DAC_OFFSET; // recenter output about center of voltage range
		if (out < 0) {
			out = 0;
		}
		if (out > 4095) {
			out = 4095;
		}
		block[i] = (uint16_t)out;
	}
}

//----------------------------inine ASM primitives----------------------------------
static inline int32_t fmul16x16_shift10(int16_t scaled, uint16_t gain){
	uint32_t result;
	uint8_t neg;

	if (scaled < 0) {
		scaled = (uint16_t)(-scaled);
		neg = 1;
		} else {
		scaled = (uint16_t)scaled;
		neg = 0;
	}

	// A general explanation if I ever share this code is:
	// a 32 bit multiply can be broken down as
	// x = x_high<<8 + x_low, y = y_high<<8 + y_low
	// x * y = (x_high<<8 + x_low)(y_high<<8 + y_low) = x_low * y_low +  (x_low * y_high) << 8 + (x_high * y_low) << 8 + (x_high * y_high) << 16

	// with inline ASM and one output, %1 is scaled, %2 is gain.
	// %A1 is scaled low byte, %B1 scaled high byte
	// %A2 is gain low byte, %B2 gain high byte
	// %A0 %B0 %C0 %D0 are the result bytes, in ascending order by significance

	asm volatile (
	// x_low * y_low
		"mul %A1, %A2 \n\t"
		"mov %A0, r0 \n\t" // result_0
		"mov %B0, r1 \n\t" // result_1
		"clr %C0 \n\t" // result_2
		"clr %D0 \n\t" // result_3

	// (x_low * y_high) << 8
		"mul %A1, %B2 \n\t"
		"add %B0, r0 \n\t" // result_1 += low
		"adc %C0, r1 \n\t" // result_2 += high + carry

	// (x_high * y_low) << 8
		"mul %B1, %A2 \n\t"
		"add %B0, r0 \n\t" // result_1 += low
		"adc %C0, r1 \n\t" // result_2 += high + carry
		"clr r1 \n\t"
		"adc %D0, r1 \n\t" // result_3 += carry

	// (x_high * y_high) << 16
		"mul %B1, %B2 \n\t"
		"add %C0, r0 \n\t" // result_2 += low
		"adc %D0, r1 \n\t" // result_3 += high + carry

	// drop low byte for gain shift ( >>8)
		"mov %A0, %B0 \n\t"
		"mov %B0, %C0 \n\t"
		"mov %C0, %D0 \n\t"
		"clr %D0 \n\t"

	// >>2 to get >>10 total
		"ror %C0 \n\t"
		"ror %B0 \n\t"
		"ror %A0 \n\t"
		"clc \n\t"
		"ror %C0 \n\t"
		"ror %B0 \n\t"
		"ror %A0 \n\t"

	// restore zero register
		"clr r1 \n\t"
		: "=&r"(result) // outputs
		: "r"((uint16_t)scaled), "r"(gain) // inputs
		: "r0", "r1", "cc" // clobbers
	); // 32 cycles total by my count

	return neg ? -(int32_t)result : (int32_t)result;
}

//------------------------------------Main------------------------------------------


int main(void)
{
	init_clk();
	init_dac();
	init_envelopes();
	init_freq_lut();
	init_frame();

	// initialize voices to OFF
	for (uint8_t v = 0; v < N_VOICES; ++v) {
		voices[v].env_state = OFF;
		voices[v].note_id = 0;
		voices[v].phase = 0;
		voices[v].step = 0;
		voices[v].env_idx = 0;
		voices[v].seen_this_block = 0;
		voices[v].hold_ticks = 0;
	}

	// prefill both pfbuff banks with silence
	for (uint8_t b = 0; b < 2; ++b) {
		for (uint16_t i = 0; i < BLOCK_SIZE; ++i) {
			pfbuff[b][i] = DAC_OFFSET;
		}
	}

	// Clear key buffer
	for (uint8_t i = 0; i < KEYLEN; ++i) {
		keybuff[i] = 0;
	}

	// initialize ownership table
	for (uint8_t i = 0; i < NOTE_LUT_LEN; ++i) {
		note_owner[i] = -1;
	}

	tcc0_init(average_period, TC_WGMODE_NORMAL_gc, TC_CLKSEL_DIV1_gc, 1);
	TCC0.INTFLAGS = TC0_CCAIF_bm | TC0_OVFIF_bm; // Clear flags
	init_dma_usart();
	init_usart();
	sei();
	init_dma_dac();

	// overhead measurements, ignore
	PORTC.DIRSET = PIN0_bm | PIN1_bm | PIN2_bm | PIN3_bm | PIN4_bm;

	// Pull Power-Down high
	PORTC.DIRSET = PIN7_bm;
	PORTC.OUTSET = PIN7_bm;

	while (1)
	{
		if((DMA.INTFLAGS & DMA_CH2TRNIF_bm)){
			scope_busy = 0;
			DMA.INTFLAGS = DMA_CH2TRNIF_bm;
		}

		if(fillflag) {
			fillflag = 0;
			PORTC.OUTSET = PIN0_bm | PIN3_bm;
			update_voices_from_keybuff();
			PORTC.OUTCLR = PIN3_bm;

			lock_cbuff = cbuff;
			PORTC.OUTSET = PIN2_bm;
			blockfill(pfbuff[1 ^ lock_cbuff]); // fill next half
			PORTC.OUTCLR = PIN2_bm;
			if (++scope_block_counter >= SCOPE_FRAME_SKIP) {
				if (!scope_busy) {
					scope_block_counter = 0;
					PORTC.OUTSET = PIN4_bm;
					scope_update_wave();
					PORTC.OUTCLR = PIN4_bm;
				}
			}
			PORTC.OUTCLR = PIN0_bm;
		}

		if (scope_ready && !scope_busy) {
			scope_busy = 1;
			scope_ready = 0;
			DMA.CH2.CTRLA = DMA_CH_ENABLE_bm | DMA_CH_BURSTLEN_1BYTE_gc | DMA_CH_SINGLE_bm;
		}
	}
}